Eclipse工程, 兼容Android Studio
-------------



