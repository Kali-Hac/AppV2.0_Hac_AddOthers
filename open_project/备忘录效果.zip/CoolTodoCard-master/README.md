# CoolTodoCard
这是一个recyclerView的Item进入以及退出的动画项目，我参照DefaultItemAnimator类，并加入了一些其他的动画效果。具体情况请看代码，其实并不复杂。


我是从dribbble中获得的灵感[dribbble](https://dribbble.com/shots/2375358-Goal-App-Animation)

欢迎完善。

# Preview
看起来可能是这个样子

![todolist card](http://img.blog.csdn.net/20151128165330538)
