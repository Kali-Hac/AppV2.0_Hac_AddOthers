package com.scrat.app.selectorlibrary.model;

/**
 * Created by yixuanxuan on 16/10/12.
 */

public interface ISelectImageItem {
    String getImgPath();
    boolean isChecked();
    void setChecked(boolean checked);
}
