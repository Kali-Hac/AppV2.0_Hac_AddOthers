package cn.refactor.cutoloadingviewdemo.header;

/**
 * Create by andy (https://github.com/andyxialm)
 * Create time: 16/10/11 16:50
 * Description :OnRefreshBeginListener
 */
public interface OnRefreshBeginListener {
    /**
     * loading begin
     */
    void onRefreshBegin();
}