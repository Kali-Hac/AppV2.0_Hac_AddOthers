# DoubleScroll

处理一个两层滑动view的自定义布局，以最少的代码实现，可扩展自定义View~

#演示效果

![weiget Effect](./Screenshot/index.gif)

#小广告
[安卓适配最佳解决方案](https://github.com/georgeyang1024/DpsGenerate)
